<?php
class TFTherapists_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return 'tf-therapists';
    }
    
    public function get_title() {
        return esc_html__( 'TF Therapists', 'themesflat-core' );
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }
    
    public function get_categories() {
        return [ 'themesflat_addons' ];
    }

	public function get_style_depends(){
		return ['tf-therapists'];
	}

	protected function register_controls() {
        // Start Posts Query        
			$this->start_controls_section( 
				'section_posts_query',
	            [
	                'label' => esc_html__('Query', 'themesflat-core'),
	            ]
	        );

	        $this->add_control( 
					'posts_per_page',
		            [
		                'label' => esc_html__( 'Posts Per Page', 'themesflat-core' ),
		                'type' => \Elementor\Controls_Manager::NUMBER,
		                'default' => '4',
		            ]
		        );

		        $this->add_control( 
		        	'order_by',
					[
						'label' => esc_html__( 'Order By', 'themesflat-core' ),
						'type' => \Elementor\Controls_Manager::SELECT,
						'default' => 'date',
						'options' => [						
				            'date' => 'Date',
				            'ID' => 'Post ID',			            
				            'title' => 'Title',
						],
					]
				);

				$this->add_control( 
					'order',
					[
						'label' => esc_html__( 'Order', 'themesflat-core' ),
						'type' => \Elementor\Controls_Manager::SELECT,
						'default' => 'desc',
						'options' => [						
				            'desc' => 'Descending',
				            'asc' => 'Ascending',	
						],
					]
				);

				$this->add_control( 
					'posts_categories',
					[
						'label' => esc_html__( 'Categories', 'themesflat-core' ),
						'type' => \Elementor\Controls_Manager::SELECT2,
						'options' => ThemesFlat_Addon_For_Elementor_healingy::tf_get_taxonomies('therapists_category'),
						'label_block' => true,
		                'multiple' => true,
					]
				);

				$this->add_control( 
					'exclude',
					[
						'label' => esc_html__( 'Exclude', 'themesflat-core' ),
						'type'	=> \Elementor\Controls_Manager::TEXT,	
						'description' => esc_html__( 'Post Ids Will Be Inorged. Ex: 1,2,3', 'themesflat-core' ),
						'default' => '',
						'label_block' => true,				
					]
				);

				$this->add_control( 
					'sort_by_id',
					[
						'label' => esc_html__( 'Sort By ID', 'themesflat-core' ),
						'type'	=> \Elementor\Controls_Manager::TEXT,	
						'description' => esc_html__( 'Post Ids Will Be Sort. Ex: 1,2,3', 'themesflat-core' ),
						'default' => '',
						'label_block' => true,				
					]
				);

				$this->add_group_control( 
					\Elementor\Group_Control_Image_Size::get_type(),
					[
						'name' => 'thumbnail',
						'default' => 'full',
					]
				);

				$this->add_control( 
		        	'layout',
					[
						'label' => esc_html__( 'Columns', 'themesflat-core' ),
						'type' => \Elementor\Controls_Manager::SELECT,
						'default' => 'column-4',
						'options' => [
							'column-1' => esc_html__( '1', 'themesflat-core' ),
							'column-2' => esc_html__( '2', 'themesflat-core' ),
							'column-3' => esc_html__( '3', 'themesflat-core' ),
							'column-4' => esc_html__( '4', 'themesflat-core' ),
						],
					]
				);	
			
			$this->end_controls_section();
        // /.End Posts Query

		// Start General Style 
			$this->start_controls_section( 
				'section_style_general',
				[
					'label' => esc_html__( 'General', 'themesflat-core' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);

			$this->add_responsive_control( 
				'padding',
				[
					'label' => esc_html__( 'Padding Spacing', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'default' => [
						'top' => '15',
						'right' => '15',
						'bottom' => '15',
						'left' => '15',
						'unit' => 'px',
						'isLinked' => true,
					],
					'selectors' => [
						'{{WRAPPER}} .wrap-therapists-post .item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],					
				]
			);	

			$this->add_responsive_control( 
				'margin',
				[
					'label' => esc_html__( 'Margin Spacing', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'allowed_dimensions' => [ 'right', 'left' ],
					'default' => [
						'right' => '',
						'left' => '',
						'unit' => 'px',
						'isLinked' => true,
					],
					'selectors' => [
						'{{WRAPPER}} .wrap-therapists-post .item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);  

			$this->add_responsive_control( 
				'padding_inner',
				[
					'label' => esc_html__( 'Padding Inner', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'selectors' => [
						'{{WRAPPER}} .wrap-therapists-post .item .therapists-post' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],					
				]
			);	

			$this->add_responsive_control( 
				'margin_inner',
				[
					'label' => esc_html__( 'Margin Inner', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'selectors' => [
						'{{WRAPPER}} .wrap-therapists-post .item .therapists-post' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			
			$this->end_controls_section();    
		// /.End General Style

		// Start Post Icon Style 
		$this->start_controls_section( 
			'image_hei',
			[
				'label' => esc_html__( 'Image', 'themesflat-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control( 
			'image_sv',
			[
				'label' => esc_html__( 'Image Height', 'themesflat-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'rem' => [
						'min' => 0,
						'max' => 10,
						'step' => 0.1,
					],
					'em' => [
						'min' => 0,
						'max' => 10,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tf-therapists-wrap .therapists-post .features-post img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section(); 


		// Start Title Style 
			$this->start_controls_section( 
				'section_style_title',
				[
					'label' => esc_html__( 'Title', 'themesflat-core' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);

			$this->add_group_control( 
	        	\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'typography',
					'label' => esc_html__( 'Typography', 'themesflat-core' ),
					'selector' => '{{WRAPPER}} .wrap-therapists-post .therapists-post .title ',
				]
			); 

			$this->add_responsive_control( 
				'margin_title',
				[
					'label' => esc_html__( 'Margin', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'selectors' => [
						'{{WRAPPER}} .wrap-therapists-post .therapists-post .title ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);  	

			$this->start_controls_tabs( 
				'background_title_tabs',
				);
				$this->start_controls_tab( 
					'title_style_normal_tab',
					[
						'label' => esc_html__( 'Normal', 'themesflat-core' ),
					] ); 
					$this->add_control( 
						'title_color',
						[
							'label' => esc_html__( 'Color', 'themesflat-core' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .wrap-therapists-post .therapists-post .title a' => 'color: {{VALUE}}',
							],
							
							
						]
					);  

				$this->end_controls_tab();

				$this->start_controls_tab( 
					'title_style_hover_tab',
					[
						'label' => esc_html__( 'Hover', 'themesflat-core' ),
					] );

					$this->add_control( 
						'title_color_hover',
						[
							'label' => esc_html__( 'Color Hover', 'themesflat-core' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .wrap-therapists-post  .therapists-post  .title a:hover' => 'color: {{VALUE}}',
							],
						]
					);   

					
				$this->end_controls_tab();
			$this->end_controls_tabs(); 
			
			$this->end_controls_section();    
		// /.End Title Style

		// Start Description Style 
			$this->start_controls_section( 
				'section_style_desc',
				[
					'label' => esc_html__( 'Position', 'themesflat-core' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);	

			$this->add_group_control( 
	        	\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'typography_desc',
					'label' => esc_html__( 'Typography', 'themesflat-core' ),
					'selector' => '{{WRAPPER}} .wrap-therapists-post .therapists-post .category-therapists a',
				]
			);

			$this->add_control( 
				'desc_color',
				[
					'label' => esc_html__( 'Color', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .wrap-therapists-post .therapists-post .category-therapists a' => 'color: {{VALUE}}',
					],
					
				]
			); 

			$this->add_responsive_control( 
				'margin_desc',
				[
					'label' => esc_html__( 'Margin', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'selectors' => [
						'{{WRAPPER}} .wrap-therapists-post .therapists-post .category-therapists' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);  

		
			
			$this->end_controls_section();    
		// /.End Description Style

		// Start Description Style 
		$this->start_controls_section( 
			'section_style_icon',
			[
				'label' => esc_html__( 'Icon Social', 'themesflat-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);	
		$this->add_control( 
			'bg_color_item_icon',
			[
				'label' => esc_html__( 'Background Color', 'themesflat-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .wrap-therapists-post .therapists-post .list-social' => 'background-color: {{VALUE}}',
				],
				
			]
		);
		$this->add_responsive_control( 
			'icon_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'themesflat-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' , '%' ],
				'selectors' => [
					'{{WRAPPER}} .wrap-therapists-post .therapists-post .list-social' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 
			'item_icon_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'themesflat-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .wrap-therapists-post .therapists-post .list-social' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'carousel_arrow' => 'yes',
				]
			]
		);
		$this->add_control( 
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'themesflat-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .wrap-therapists-post .therapists-post .list-social li a i' => 'color: {{VALUE}}',
				],
				
			]
		);
		$this->add_control( 
			'icon_color_hover',
			[
				'label' => esc_html__( 'Icon Color Hover', 'themesflat-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .wrap-therapists-post .therapists-post .list-social li a:hover i' => 'color: {{VALUE}}',
				],
				
			]
		);
		$this->add_control( 
			'bg_icon_color',
			[
				'label' => esc_html__( 'Background Icon Color', 'themesflat-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .wrap-therapists-post .therapists-post .list-social li a' => 'background-color: {{VALUE}}',
				],
				
			]
		);
		$this->add_control( 
			'bg_icon_color_hover',
			[
				'label' => esc_html__( 'Background Icon Color Hover', 'themesflat-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .wrap-therapists-post .therapists-post .list-social li a:hover' => 'background-color: {{VALUE}}',
				],
				
			]
		);
		$this->add_group_control( 
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'icon_border',
				'label' => esc_html__( 'Border', 'themesflat-core' ),
				'selector' => '{{WRAPPER}} .wrap-therapists-post .therapists-post .list-social li a',
			]
		);

	
		
		$this->end_controls_section();    
	// /.End Description Style

	

	}

	protected function render($instance = []) {
		$settings = $this->get_settings_for_display();


		$this->add_render_attribute( 'tf_therapists_wrap', ['class' => ['tf-therapists-wrap', 'themesflat-therapists-taxonomy' ], 'data-tabid' => $this->get_id()] );


		if ( get_query_var('paged') ) {
           $paged = get_query_var('paged');
        } elseif ( get_query_var('page') ) {
           $paged = get_query_var('page');
        } else {
           $paged = 1;
        }
		$query_args = array(
            'post_type' => 'therapists',
            'posts_per_page' => $settings['posts_per_page'],
            'paged'     => $paged
        );

        if (! empty( $settings['posts_categories'] )) {        	
        	$query_args['tax_query'] = array(
							        array(
							            'taxonomy' => 'therapists_category',
							            'field'    => 'slug',
							            'terms'    => $settings['posts_categories']
							        ),
							    );
        }        
        if ( ! empty( $settings['exclude'] ) ) {				
			if ( ! is_array( $settings['exclude'] ) )
				$exclude = explode( ',', $settings['exclude'] );

			$query_args['post__not_in'] = $exclude;
		}

		$query_args['orderby'] = $settings['order_by'];
		$query_args['order'] = $settings['order'];

		if ( $settings['sort_by_id'] != '' ) {	
			$sort_by_id = array_map( 'trim', explode( ',', $settings['sort_by_id'] ) );
			$query_args['post__in'] = $sort_by_id;
			$query_args['orderby'] = 'post__in';
		}

		$query = new WP_Query( $query_args );
		if ( $query->have_posts() ) : ?>
<div <?php echo $this->get_render_attribute_string('tf_therapists_wrap'); ?>>

    <div class="wrap-therapists-post row <?php echo esc_attr($settings['layout']); ?> ">

        <?php while ( $query->have_posts() ) : $query->the_post(); 
                            global $post;
                            $facebook = get_post_meta($post->ID, 'facebook_therapists_value', true);
                            $twitter = get_post_meta($post->ID, 'twitter_therapists_value', true);
                            $linkedin = get_post_meta($post->ID, 'linkedin_therapists_value', true);
                            $youtube = get_post_meta($post->ID, 'youtube_therapists_value', true);
                            $custom1 = get_post_meta($post->ID, 'custom1_therapists_value', true);
                            $custom2 = get_post_meta($post->ID, 'custom2_therapists_value', true);
                            $facebook_icon = get_post_meta($post->ID, 'facebook_icon_value', true);
                            $twitter_icon = get_post_meta($post->ID, 'twitter_icon_value', true);
                            $linkedin_icon = get_post_meta($post->ID, 'linkedin_icon_value', true);
                            $youtube_icon = get_post_meta($post->ID, 'youtube_icon_value', true);
                            $custom1_icon = get_post_meta($post->ID, 'custom1_icon_value', true);
                            $custom2_icon = get_post_meta($post->ID, 'custom2_icon_value', true);
                ?>
        <div class="item">
            <div class="therapists-post">
                <div class="features-post">
                    <?php 
                                        $get_id_post_thumbnail = get_post_thumbnail_id();
                                        echo sprintf('<img src="%s" alt="image">', \Elementor\Group_Control_Image_Size::get_attachment_image_src( $get_id_post_thumbnail, 'thumbnail', $settings ));
                                    ?>
                    <?php if ( !empty($facebook_icon) || !empty($twitter_icon) || !empty($linkedin_icon) || !empty($youtube_icon) || !empty($custom1_icon) || !empty($custom2_icon )): ?>
                    <ul class="list-social">
                        <?php if ( !empty($facebook) ): ?>
                        <li>
                            <a href="<?php echo esc_url($facebook); ?>"><i
                                    class="icon-healingy-<?php echo esc_attr($facebook_icon); ?>"></i></a>
                        </li>
                        <?php endif; ?>
                        <?php if ( !empty($twitter) ): ?>
                        <li>
                            <a href="<?php echo esc_url($twitter) ?>"><i
                                    class="icon-healingy-<?php echo esc_attr($twitter_icon); ?>"></i></a>
                        </li>
                        <?php endif; ?>
                        <?php if ( !empty($linkedin) ): ?>
                        <li>
                            <a href="<?php echo esc_url($linkedin) ?>"><i
                                    class="icon-healingy-<?php echo esc_attr($linkedin_icon); ?>2"></i></a>
                        </li>
                        <?php endif; ?>
                        <?php if ( !empty($youtube) ): ?>
                        <li>
                            <a href="<?php echo esc_url($youtube) ?>"><i
                                    class="icon-healingy-<?php echo esc_attr($youtube_icon); ?>"></i></a>
                        </li>
                        <?php endif; ?>
                        <?php if ( !empty($custom1) ): ?>
                        <li>
                            <a href="<?php echo esc_url($custom1) ?>"><i
                                    class="icon-healingy-<?php echo esc_attr($custom1_icon); ?>"></i></a>
                        </li>
                        <?php endif; ?>
                        <?php if ( !empty($custom2) ): ?>
                        <li>
                            <a href="<?php echo esc_url($custom2) ?>"><i
                                    class="icon-healingy-<?php echo esc_attr($custom2_icon); ?>"></i></a>
                        </li>
                        <?php endif; ?>
                    </ul>
                    <?php endif; ?>
                </div>
                <div class="content">
                    <h5 class="title">
                        <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                    </h5>
                    <div class="category-therapists">
                        <?php echo esc_attr ( the_terms( get_the_ID(), 'therapists_category', '', ', ', '' ) ); ?></div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>

        <?php wp_reset_postdata(); ?>
    </div>
</div>
<?php
		else:
			esc_html_e('No posts found', 'themesflat-core');
		endif;
			
	}	

}